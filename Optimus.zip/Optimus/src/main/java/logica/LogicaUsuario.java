 /**
 * @author bizagi
 */

package logica;

import java.util.ArrayList;
import persistencia.UsuarioDAO;

public class LogicaUsuario {  
    private ArrayList<Usuario> lista;
    
    public ArrayList<Usuario> getListaUsuarios() {
        return lista;
    }
    
	//Carga la información de todos los usuarios en la BD
    public boolean cargarTodosLosUsuarios() {
        UsuarioDAO dao = new UsuarioDAO();
        lista = dao.consultarUsuarios();
        if (lista.size() > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    
    //Carga la información de un usuario en la BD
    public Usuario cargarUnUsuario(int id) {
        UsuarioDAO dao = new UsuarioDAO();
        Usuario u = dao.consultarUsuario(id);
        return u;
    }
    
    //Guarda la información de un usuario capturada desde el formulario
    public boolean guardarUsuario(Usuario u) {
        UsuarioDAO dao = new UsuarioDAO();
        if (u.getId() == 0) {
            int id = dao.guardarNuevoUsuario(u);
            if (id > 0) {
                return true;
            } else {
                return false;
            }
        }
        else {
            int filas = dao.guardarUsuarioExistente(u);
            if (filas == 1) {
                return true;
            } else {
                return false;
            }
        }
    } 
}