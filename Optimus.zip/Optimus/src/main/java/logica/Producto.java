
/**
 * @author Grupo Optimus
 */

package logica;

//Clase Producto para crear objetos productos de acuerdo a base de datos
public class Producto { 
    //Atributos
    private int idProducto = 0;
    private String NombreProducto;
    private int idTipoReferencia;
    private int diametromin;
    private int diametromax;
    private int largomin;
    private int largomax;
    private int alto;
    private int pesomin;
    private int pesomax;
    
    //Costructores
    public Producto() {
    }  

    public Producto(String NombreProducto, int idTipoReferencia, int  diametromin, int  diametromax, int  largomin, int  largomax, int  alto, int  pesomin, int  pesomax) {
        this.NombreProducto = NombreProducto;
        this.idTipoReferencia = idTipoReferencia;
        this.diametromin = diametromin;
        this.diametromax = diametromax;
        this.largomin = largomin;
        this.largomax = largomax;
        this.alto = alto;
        this.pesomin = pesomin;
        this.pesomax = pesomax;
    }

    public Producto(int idProducto, String NombreProducto, int idTipoReferencia, int  diametromin, int  diametromax, int  largonmin, int largomax, int  alto, int  pesomin, int  pesomax) {
        this.idProducto = idProducto;
        this.NombreProducto = NombreProducto;
        this.idTipoReferencia = idTipoReferencia;
        this.diametromin = diametromin;
        this.diametromax = diametromax;
        this.largomin = largomin;
        this.largomax = largomax;
        this.alto = alto;
        this.pesomin = pesomin;
        this.pesomax = pesomax;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String NombreProducto) {
        this.NombreProducto = NombreProducto;
    }

    public int getIdTipoReferencia() {
        return idTipoReferencia;
    }

    public void setIdTipoReferencia(int idTipoReferencia) {
        this.idTipoReferencia = idTipoReferencia;
    }

    public int getDiametromin() {
        return diametromin;
    }

    public void setDiametromin(int  diametromin) {
        this.diametromin = diametromin;
    }

    public int getDiametromax() {
        return diametromax;
    }

    public void setDiametromax(int diametromax) {
        this.diametromax = diametromax;
    }

    public int getLargomin() {
        return largomin;
    }

    public void setLargomin(int  largomin) {
        this.largomin = largomin;
    }

    public int getLargomax() {
        return largomax;
    }

    public void setLargomax(int  largomax) {
        this.largomax = largomax;
    }

    public int getAlto() {
        return alto;
    }

    public void setAlto(int  alto) {
        this.alto = alto;
    }

    public int getPesomin() {
        return pesomin;
    }

    public void setPesomin(int  pesomin) {
        this.pesomin = pesomin;
    }

    public int getPesomax() {
        return pesomax;
    }

    public void setPesomax(int  pesomax) {
        this.pesomax = pesomax;
    }
}